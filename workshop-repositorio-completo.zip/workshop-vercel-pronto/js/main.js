/* ============================================================
   Workshop: O Que Um Gestor de Marketplace Faz
   Lógica da landing — checkout via API InfinitePay (serverless)
   ============================================================ */

/* ---------- Checkout ---------- */

const BTN_LOADING_TEXT = 'Gerando pagamento…';
const ERROR_MESSAGE = 'Não foi possível iniciar o pagamento. Tente novamente em alguns instantes.';

/**
 * Inicia o fluxo de checkout:
 * 1. Coloca o botão em estado de carregamento
 * 2. Chama a função serverless /api/create-checkout
 * 3. Redireciona o usuário para a URL de pagamento da InfinitePay
 * 4. Em caso de erro, restaura o botão e exibe mensagem amigável
 * @param {HTMLElement} btn - botão que disparou o checkout
 */
async function iniciarCheckout(btn) {
  if (btn.dataset.loading === '1') return; // evita cliques duplos
  const originalText = btn.textContent;
  setLoading(btn, true);

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 15000);

    const res = await fetch('/api/create-checkout', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      signal: controller.signal
    });
    clearTimeout(timeout);

    if (!res.ok) throw new Error('HTTP ' + res.status);

    const data = await res.json();
    if (!data || typeof data.url !== 'string' || !data.url.startsWith('https://')) {
      throw new Error('Resposta inválida');
    }

    window.location.href = data.url;
  } catch (err) {
    setLoading(btn, false, originalText);
    mostrarErro(btn);
  }
}

/** Alterna o estado visual de carregamento do botão. */
function setLoading(btn, loading, originalText) {
  if (loading) {
    btn.dataset.loading = '1';
    btn.dataset.original = btn.textContent;
    btn.textContent = BTN_LOADING_TEXT;
    btn.style.opacity = '.7';
    btn.style.pointerEvents = 'none';
  } else {
    btn.dataset.loading = '';
    btn.textContent = originalText || btn.dataset.original || btn.textContent;
    btn.style.opacity = '';
    btn.style.pointerEvents = '';
  }
}

/** Exibe mensagem de erro amigável próxima ao botão (some sozinha). */
function mostrarErro(btn) {
  let note = btn.parentElement.querySelector('.pay-error');
  if (!note) {
    note = document.createElement('div');
    note.className = 'pay-error';
    note.setAttribute('role', 'alert');
    note.style.cssText = 'margin-top:10px;font-size:.83rem;color:#ff6b6b;';
    btn.insertAdjacentElement('afterend', note);
  }
  note.textContent = ERROR_MESSAGE;
  clearTimeout(note._t);
  note._t = setTimeout(() => note.remove(), 6000);
}

/* Liga todos os botões de compra ao novo fluxo */
document.querySelectorAll('.js-checkout').forEach((a) => {
  a.addEventListener('click', (e) => {
    e.preventDefault();
    iniciarCheckout(a);
  });
});

/* ---------- Contagem regressiva até 16/07/2026 18h30 (Brasília) ---------- */

const target = new Date('2026-07-16T18:30:00-03:00').getTime();
const el = {
  d: document.getElementById('cd'),
  h: document.getElementById('ch'),
  m: document.getElementById('cm'),
  s: document.getElementById('cs')
};

function tick() {
  const diff = Math.max(0, target - Date.now());
  el.d.textContent = String(Math.floor(diff / 864e5)).padStart(2, '0');
  el.h.textContent = String(Math.floor((diff % 864e5) / 36e5)).padStart(2, '0');
  el.m.textContent = String(Math.floor((diff % 36e5) / 6e4)).padStart(2, '0');
  el.s.textContent = String(Math.floor((diff % 6e4) / 1e3)).padStart(2, '0');
}
if (el.d && el.h && el.m && el.s) {
  tick();
  setInterval(tick, 1000);
}

/* ---------- Reveal on scroll ---------- */

const io = new IntersectionObserver((entries) => {
  entries.forEach((e) => {
    if (e.isIntersecting) {
      e.target.classList.add('in');
      io.unobserve(e.target);
    }
  });
}, { threshold: 0.12 });
document.querySelectorAll('.rv').forEach((x) => io.observe(x));

/* ---------- Barra fixa de compra ---------- */

const hero = document.querySelector('.hero');
const priceBox = document.querySelector('.pricebox');
const sticky = document.getElementById('sticky');

function updateSticky() {
  if (!hero || !priceBox || !sticky) return;
  const past = window.scrollY > hero.offsetHeight * 0.65;
  const r = priceBox.getBoundingClientRect();
  const overPrice = r.top < window.innerHeight && r.bottom > 0;
  sticky.classList.toggle('on', past && !overPrice);
}
window.addEventListener('scroll', updateSticky, { passive: true });
updateSticky();
